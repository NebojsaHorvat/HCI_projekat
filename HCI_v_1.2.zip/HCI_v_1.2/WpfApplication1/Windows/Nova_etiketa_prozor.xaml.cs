﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApplication1.Klase;


namespace WpfApplication1.Windows
{
    /// <summary>
    /// Interaction logic for Nova_etiketa_prozor.xaml
    /// </summary>

    public partial class Nova_etiketa_prozor : Window
    {
        bool jedinstven = false;
        private string _opis;
        private Color _color;
        bool izmena = false;
        public Nova_etiketa_prozor()
        {
            InitializeComponent();
        }

        private void ClrPcker_Background_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color> e)
        {
            _color = (Color)ClrPcker_Background.SelectedColor;
        }
        


        private void Odustani_clicked(object sender, RoutedEventArgs e)
        {
           
            this.Close();
        }

        private void Potvrdi_clicked(object sender, RoutedEventArgs e)
        {
            if (id_textbox.Text == "")
            {
                Error_message.Text = "ID ne sme ostati prazan";
            }
            else if (!jedinstven)
            {
                Error_message.Text = "ID vec postoji";
            }
            else
            {
                if(izmena)
                {
                    Etiketa et = MainWindow.model.etikete[id_textbox.Text];
                    MainWindow.etiketeObservable.Remove(et);
                    MainWindow.model.etikete.Remove(et.ID);
                }
                Color boja = (Color)ClrPcker_Background.SelectedColor;
                Etiketa etiketa = new Etiketa(boja, id_textbox.Text, opis_text_box.Text);
                MainWindow.Dodaj_etiketu(etiketa);
                MainWindow.etiketeObservable.Add(etiketa);
                if (New_species_window.Etikete != null)
                    New_species_window.Etikete.Add(etiketa);

                this.Close();
            }

        }



        private void promenjen_fokus(object sender, RoutedEventArgs e)
        {
            if (MainWindow.model.etikete.ContainsKey(id_textbox.Text))
            {
                Error_message.Text = "ID vec postoji";
            }
            else
            {
                Error_message.Text = "";
                jedinstven = true;
            }
        }

        public void ubacivanjeVrednostiUProzor(Etiketa e)
        {
            Color c = Color.FromScRgb(e.sca, e.scr, e.scg, e.scb);
            izmena = true;
            jedinstven = true;
            ClrPcker_Background.SelectedColor = c;
            id_textbox.Text = e.ID;
            opis_text_box.Text = e.Opis;
            id_textbox.IsEnabled = false;

        }
       


    }
}
