﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1.Klase
{
    [Serializable]
    public class Model
    {
        
        public  Dictionary<string, Tip> tipovi;
        public  Dictionary<string, Etiketa> etikete;
        public  Dictionary<string, Vrsta> vrste;
        public Model()
        {
            
            tipovi = new Dictionary<string, Tip>();
            etikete = new Dictionary<string, Etiketa>();
            vrste = new Dictionary<string, Vrsta>();
             
        }

        public Model(Dictionary<string, Tip> t, Dictionary<string, Etiketa> e,  Dictionary<string, Vrsta> v)
        {
            tipovi = t;
            etikete = e;
            vrste = v;
        }
    }
}
