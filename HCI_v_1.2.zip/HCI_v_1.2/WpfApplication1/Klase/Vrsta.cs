﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApplication1.Klase
{
    [Serializable]
    public class Vrsta
    {
        
        
        private bool opasna_za_ljude;

        public bool Opasna_za_ljude
        {
            get { return opasna_za_ljude; }
            set { opasna_za_ljude = value; }
        }

        public string Opasna_za_ljude_string
        {
            get
            {
                if (opasna_za_ljude)
                    return "Da";
                else
                    return "Ne";
            }
        }

        private bool naseljeni_region;

        public bool Naseljeni_region
        {
            get { return naseljeni_region; }
            set { naseljeni_region = value; }
        }
        
        public string Naseljeni_region_string
        {
            get
            {
                if(naseljeni_region)
                    return "Da";
                else
                    return "Ne";
            }      
        }

        private bool crvena_lista;

        public bool Crvena_lista
        {
            get { return crvena_lista; }
            set { crvena_lista = value; }
        }
        
        public string Crvena_lista_string
        {
            get
            {
                if (crvena_lista)
                    return "Da";
                else
                    return "Ne";
            }
        }
        private List<Etiketa> etikete;

        public List<Etiketa> Etikete
        {
            get { return etikete; }
            set { etikete = value; }
        }
        public List<string> Etikete_String
        {
            get
            {
                List<string> sEtikete = new List<string>();
                foreach (var et in etikete)
                {
                    sEtikete.Add(et.ID);
                }
                return sEtikete;
            }
        }
       

        public String Tip_ID
        {
            get { return Tip.ID; }
            set { Tip.ID = value; }
        }

        public String Tip_slika
        {
            get { return Tip.Ikonica; }
            set { Tip.Ikonica = value; }
        }
        
        private Tip tip;

        public Tip Tip
        {
            get { return tip; }
            set { tip = value; }
        }
        

        private String ime;

        public String Ime
        {
            get { return ime; }
            set { ime = value; }
        }
        private String opis;
    
        public String Opis
        {
            get { return opis; }
            set { opis = value; }
        }
        private String turisticki_status;

        public String Turisticki_status
        {
            get { return turisticki_status; }
            set { turisticki_status = value; }
        }
        private String  datum;

        public String  Datum
        {
            get { return datum; }
            set { datum = value; }
        }

        private double prihod_od_turizma;

        public double Prihod_od_turizma
        {
            get { return prihod_od_turizma; }
            set { prihod_od_turizma = value; }
        }
        

        
        
        

        
        public Vrsta(string id_,string ime_,string opis_,string ts,string dat,double prihod,Tip t,List<Etiketa> e,bool ozlj,bool cl,bool nr,string sv)
        {
            id = id_;
            ime = ime_;
            opis = opis_;
            turisticki_status = ts;
            datum = dat;
            prihod_od_turizma = prihod;
            tip = t;
            etikete = e;
            opasna_za_ljude = ozlj;
            crvena_lista = cl;
            naseljeni_region = nr;
            slika_vrste = sv;
        }

        public string id;
        
        public string ID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        private string slika_vrste;

        public string Slika_vrste
        {
            get { return slika_vrste; }
            set { slika_vrste = value; }
        }
        
        
    }
}
