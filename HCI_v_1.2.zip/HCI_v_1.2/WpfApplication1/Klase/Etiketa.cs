﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace WpfApplication1.Klase
{

    [Serializable]
    public class Etiketa
    {
        private string _ID;
        private string _opis;
        public float sca,scb,scg,scr;
        
       public Etiketa(Color color,string id,string opis)
        {

            sca = color.ScA;
            scb = color.ScB;
            scg = color.ScG;
            scr = color.ScR;
            _ID = id;
            _opis = opis;
        }
        public Etiketa() { }

        

        public string ID
        {
            get
            {
                return _ID;
            }
            set
            {
                _ID = value;
            }
        }
        public string Opis
        {
            get
            {
                return _opis;
            }
            set
            {
                _opis = value;
            }
        }
        public override string ToString()
        {
            return ID;
        }

    }
}
