﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApplication1.Klase;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window ,INotifyPropertyChanged
    {
        public static Model model = new Model();

        /*
        public static  Dictionary<string,Tip> tipovi;
        public static  Dictionary<string, Etiketa> etikete;
        public static Dictionary<string, Vrsta> vrste;
        */

        public static ObservableCollection<Tip> tipoviObservable
        {
            get;
            set;

        }
        public static ObservableCollection<Vrsta> vrsteObservable
        {
            get;
            set;

        }
        public static ObservableCollection<Etiketa> etiketeObservable
        {
            get;
            set;

        }
         
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
            this.Closed += close_action;
            /*
            tipovi = new Dictionary<string,Tip>();
            etikete = new Dictionary<string, Etiketa>();
            vrste = new Dictionary<string, Vrsta>();
            */

            
            deserialize();
            
            tipoviObservable = new ObservableCollection<Tip>();
            etiketeObservable = new ObservableCollection<Etiketa>();
            vrsteObservable = new ObservableCollection<Vrsta>();

            //updejtovanje observableCollections
            updateObservable();
            
            ImageBrush imageBrush = new ImageBrush();
            imageBrush.ImageSource = new BitmapImage(new Uri(@"../../Images/world-map.jpg", UriKind.Relative));
            kanvas.Background = imageBrush;
            
        }

        private void updateObservable()
        {
            tipoviObservable.Clear();
            vrsteObservable.Clear();
            etiketeObservable.Clear();

            foreach (string st in model.tipovi.Keys)
            {
                tipoviObservable.Add(model.tipovi[st]);
            }
            foreach (string se in model.etikete.Keys)
            {
                etiketeObservable.Add(model.etikete[se]);
            }
            foreach (string sv in model.vrste.Keys)
            {
                vrsteObservable.Add(model.vrste[sv]);
            }
        }

        internal static void  Dodaj_etiketu(Etiketa e)
        {
            model.etikete.Add(e.ID, e);
            
        }
        internal static bool Sadrzi_etiketu(string id)
        {
            return model.etikete.ContainsKey(id);
        }
        internal static void Dodaj_tip(Tip t)
        {
            model.tipovi.Add(t.ID, t);
        }
        internal static bool Sadrzi_tip(string id)
        {
            return model.tipovi.ContainsKey(id);
        }
        internal static void Dodaj_vrstu(Vrsta v)
        {
            model.vrste.Add(v.id, v);
        }
        internal static bool Sadrzi_vrstu(string id)
        {
            return model.vrste.ContainsKey(id);
        }

        private void new_species_clicked(object sender, RoutedEventArgs e)
        {
            var new_species_window = new WpfApplication1.Windows.New_species_window();
            new_species_window.Show();
            
        }

        private void Novi_tip_clicked(object sender, RoutedEventArgs e)
        {
            var novi_tip_prozor = new WpfApplication1.Windows.Novi_tip_prozor();
            novi_tip_prozor.Show();
        }

        private void Nova_etiketa_clicked(object sender, RoutedEventArgs e)
        {
            var nova_etiketa_prozor = new WpfApplication1.Windows.Nova_etiketa_prozor();
            nova_etiketa_prozor.Show();
        }

        internal static void tipovi_lista(System.Collections.ObjectModel.ObservableCollection<Tip> o_tipovi)
        {
            foreach (var t in model.tipovi)
            {
                o_tipovi.Add(t.Value);
            }
        }

        private void dodaj_vrstu_clicked(object sender, RoutedEventArgs e)
        {
            var nova_vrsta_prozor = new WpfApplication1.Windows.New_species_window();
            nova_vrsta_prozor.Show();
        }

        private void dodaj_tip_clicked(object sender, RoutedEventArgs e)
        {
            var novi_tip_prozor = new WpfApplication1.Windows.Novi_tip_prozor();
            novi_tip_prozor.Show();
        }

        private void dodaj_etiketu_clicked(object sender, RoutedEventArgs e)
        {
            var nova_etiketa_prozor = new WpfApplication1.Windows.Nova_etiketa_prozor();
            nova_etiketa_prozor.Show();
        }

        protected virtual void OnPropertyChanged(string name)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(name));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;

        void close_action(object sender, EventArgs e)
        {
            IFormatter formatter = new BinaryFormatter();
            Stream stream = new FileStream("../../Resources/model.bin", FileMode.Create, FileAccess.Write, FileShare.None);

            
            try
            {
                formatter.Serialize(stream, model);
            }
            catch (SerializationException ex)
            {
                Console.Write(ex.Message + "-[]-" + ex.StackTrace);
            }

            stream.Close();
        }

        private void deserialize()
        {
            IFormatter formatter = new BinaryFormatter();
            try
            {
                Stream stream = new FileStream("../../Resources/model.bin", FileMode.Open, FileAccess.Read, FileShare.Read);
                model = (Model)formatter.Deserialize(stream);
                stream.Close();
            }
            catch (Exception )
            {
                Console.Write("Greska pri ucitavanju modela");
            }
        }

        private void obrisi_clicked(object sender, RoutedEventArgs e)
        {

            Vrsta v = (Vrsta)tabela.SelectedItem;
            if(v != null)
            {
                MainWindow.vrsteObservable.Remove(v);
                model.vrste.Remove(v.ID);
            }
            Etiketa et = (Etiketa)listaEtiketa.SelectedItem;
            if(et != null)
            {
                etiketeObservable.Remove(et);
                model.etikete.Remove(et.ID);
            }
            Tip t =(Tip) listaTipova.SelectedItem;
            if(t != null)
            {
                tipoviObservable.Remove(t);
                model.tipovi.Remove(t.ID);
            }
            
        }

        private void izmeni_clicked(object sender, RoutedEventArgs e)
        {
            Vrsta v = (Vrsta)tabela.SelectedItem;
            if (v != null)
            {
                var nova_vrsta_prozor = new WpfApplication1.Windows.New_species_window();
                nova_vrsta_prozor.Show();
                nova_vrsta_prozor.postaviElementeProzora(v);
            }
            Etiketa et = (Etiketa)listaEtiketa.SelectedItem;
            if (et != null)
            {
                
                var nova_etiketa_prozor = new WpfApplication1.Windows.Nova_etiketa_prozor();
                nova_etiketa_prozor.ubacivanjeVrednostiUProzor(et);

                nova_etiketa_prozor.Show();
            }
            Tip t = (Tip)listaTipova.SelectedItem;
            if (t != null)
            {
                var novi_tip_prozor = new WpfApplication1.Windows.Novi_tip_prozor();
                novi_tip_prozor.Show();

                novi_tip_prozor.postaviElementeProzora(t);
            }
        }

        private void deselektuj_ostale(object sender, MouseButtonEventArgs e)
        {
            listaEtiketa.SelectedItem = null;
            listaTipova.SelectedItem = null;
        }

        private void deselektuj_ostale1(object sender, SelectionChangedEventArgs e)
        {
            listaEtiketa.SelectedItem = null;
            listaTipova.SelectedItem = null;
        }

        private void delesektuj_osatale2(object sender, SelectionChangedEventArgs e)
        {
            listaEtiketa.SelectedItem = null;
            tabela.SelectedItem = null;
        }

       

        private void deselektuj_ostale3(object sender, SelectionChangedEventArgs e)
        {
            listaTipova.SelectedItem = null;
            tabela.SelectedItem = null;
        }
    }
}
